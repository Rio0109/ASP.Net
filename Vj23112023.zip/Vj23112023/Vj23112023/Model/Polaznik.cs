﻿namespace Vj23112023.Model
{
	public class Polaznik
	{
		public int Id { get; set; }
		public string Ime { get; set; }
		public string Prezime { get; set; }
	}
}
