﻿

#region Zadatak1
//Console.WriteLine("Unesite svoju godinu rođenja:");
//int godinaRodjenja = int.Parse(Console.ReadLine());
//int trenutnaGodina = DateTime.Now.Year;

//bool jePunoljetan = false;
//int imaGodina = trenutnaGodina - godinaRodjenja;
//jePunoljetan = imaGodina >= 18;

//int godinaRodjenja = int.Parse(Console.ReadLine());
//int trenutnaGodina = DateTime.Now.Year;
//bool jePunoljetan = trenutnaGodina - godinaRodjenja >= 18;



//if (jePunoljetan)
//{
//	Console.WriteLine("Korisnik je punoljetan.");
//}
//else
//{
//	Console.WriteLine("Korisnik nije punoljetan.");
//}
#endregion
#region Zadatak2
//Console.WriteLine("Da li imate administratorska prava? (da/ne)");
//string odgovor = Console.ReadLine();

//bool jeAdministrator = odgovor.ToLower() == "da";

//if (jeAdministrator)
//{
//	Console.WriteLine("Pristup odobren. Možete mijenjati postavke.");
//}
//else
//{
//	Console.WriteLine("Pristup odbijen. Nemate administratorska prava.");
//}
#endregion
#region Zadatak3
//select blok koda koji zelite pokrenuti, CTRL+K+U

//string odgovorDa = "da";

//Console.WriteLine("Da li ste član kluba? (da/ne)");
//bool jeClan = Console.ReadLine().ToLower() == odgovorDa;

//Console.WriteLine("Da li imate popust? (da/ne)");
//bool imaPopust = Console.ReadLine().ToLower() == odgovorDa;

//if(jeClan && imaPopust)
//{
//	Console.WriteLine("Imate 20% popusta na sve proizvode.");
//}
//else if (jeClan)
//{
//	Console.WriteLine("Imate 10% popusta na sve proizvode.");
//}
//else
//{
//	Console.WriteLine("Nemate popusta. Razmislite o učlanjenju za buduće pogodnosti.");
//}

#endregion
#region Zadatak4
//Console.WriteLine("Unesi neki broj za provjeru pozitivnosti: ");
//int broj = int.Parse(Console.ReadLine());
//bool jePozitivan = broj > 0;
//if (jePozitivan)
//{
//	Console.WriteLine("Broj je pozitivan.");
//}
//else
//{
//	Console.WriteLine("Broj nije pozitivan.");
//}

#endregion
#region Zadatak5
//napraviti zadatak koji provjerava je li broj unutar određenog raspona
//broj unesen od korisnika veci ili jedank 10, i manji ili jednak 20
//Ispis: Broj je unutar raspona. / "Broj nije unutar raspona."


//+ && - = -
//+ && + = +
//- && - = -
//+ && + = +


//Console.WriteLine("Unesi broj za proveru raspona 'veci ili jedank 10, i manji ili jednak 20'");
//int broj = int.Parse(Console.ReadLine());
//bool uRasponu = broj >= 10 && broj <= 20;


//if (uRasponu)
//{
//	Console.WriteLine("Broj je unutar raspona.");
//}
//else
//{
//	Console.WriteLine("Broj nije unutar raspona.");
//}
#endregion
#region Zadatak6
//applikacija gdje korisnik unosi snagu motora u kilovatima (kW),
//aplikacija izračunava ekvivalent u konjskim snagama (KS) i
//zatim koristi bool varijable i if naredbe za određivanje je li snaga veća, manja ili jednaka od 100 KS.

//*Pretvorba u konjske snage (1 kW = 1.359622 KS)
//Console.WriteLine("Unesite snagu motora u kilovatima (kW):");
//double snagaUKilovatima = double.Parse(Console.ReadLine());
//// Pretvorba u konjske snage (1 kW = 1.359622 KS)
//double snagaUKonjskimSnagama = snagaUKilovatima * 1.359622;

//Console.WriteLine($"Snaga motora u konjskim snagama (KS): {snagaUKonjskimSnagama:F2} KS");

//bool jeSnagaVecaOd100KS = snagaUKonjskimSnagama > 100;
//bool jeSnagaManjaOd100KS = snagaUKonjskimSnagama < 100;
//bool jeSnagaJednaka100KS = snagaUKonjskimSnagama == 100;

//if (jeSnagaVecaOd100KS)
//{
//	Console.WriteLine("Snaga motora je veća od 100 KS.");
//}
//else if (jeSnagaManjaOd100KS)
//{
//	Console.WriteLine("Snaga motora je manja od 100 KS.");
//}
//else if (jeSnagaJednaka100KS)
//{
//	Console.WriteLine("Snaga motora je jednaka 100 KS.");
//}
#endregion
#region Zadatak7
//Console.WriteLine("Izaberi jednu od opcija: 1: 'pozdrav', 2:'datum', 3:'godina', 4:'dan u tjednu', 5:'izlaz'");
//string opcija = Console.ReadLine();

//switch (opcija)
//{
//	case "1":
//        Console.WriteLine("Dobar dan!");
//        break;
//	case "2":
//        Console.WriteLine(DateTime.Now.ToString("dd.MM.yyyy"));
//        break;
//	case "3":
//		//Console.WriteLine("Godina je: {0}", DateTime.Now.Year);
//		//Console.WriteLine($"Godina je: "+DateTime.Now.Year);
//		Console.WriteLine($"Godina je: {DateTime.Now.Year}");
//		break;
//	case "4":
//		Console.WriteLine(DateTime.Now.DayOfWeek.ToString());
//		break;
//	case "5":
//		break;
//	default:
//		Console.WriteLine("Ne poznajem opciju!");
//		break;
//}

#endregion
#region Zadatak8
//Console.WriteLine("Unesite boju (crvena, plava, zelena, žuta):");
//string boja = Console.ReadLine().ToLower();
//switch (boja)
//{
//	case "crvena":
//		Console.WriteLine("Odabrali ste crvenu boju.");
//		break;
//	case "plava":
//		Console.WriteLine("Odabrali ste plavu boju.");
//		break;
//	case "zelena":
//		Console.WriteLine("Odabrali ste zelenu boju.");
//		break;
//	case "žuta":
//		Console.WriteLine("Odabrali ste žutu boju.");
//		break;
//	default:
//		Console.WriteLine("Nepoznata boja.");
//		break;
//}
#endregion
#region Zadatak9
using Vjezba29112023;

Console.WriteLine("Unesite status korisnika (Novi = 1, Aktivan = 2, Neaktivan = 3, Ispisan = 4):");
var broj = int.Parse(Console.ReadLine());
StatusKorisnika statusKorisnika = (StatusKorisnika)broj;

//switch (statusKorisnika)
//{
//	case StatusKorisnika.Novi:
//		Console.WriteLine($"Korisnik je {statusKorisnika.ToString()}");
//		break;
//	case StatusKorisnika.Aktivan:
//		Console.WriteLine("Korisnik je aktivan.");
//		break;
//	case StatusKorisnika.Neaktivan:
//		Console.WriteLine("Korisnik je neaktivan.");
//		break;
//	case StatusKorisnika.Ispisan:
//		Console.WriteLine("Korisnik je ispisan.");
//		break;
//	default:
//		break;
//}



switch (statusKorisnika)
{
	case StatusKorisnika.Novi:
	case StatusKorisnika.Aktivan:
	case StatusKorisnika.Neaktivan:
	case StatusKorisnika.Ispisan:
		Console.WriteLine($"Korisnik je {statusKorisnika.ToString()}");
		break;
	default:
		break;
}

#endregion

