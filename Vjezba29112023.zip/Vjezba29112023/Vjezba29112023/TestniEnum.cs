﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vjezba29112023
{
	public enum AlgebraTecaj
	{
		DotNet,
		CSharp,
		CPP

	}
}
