﻿namespace Vjezba29112023
{
	public enum StatusKorisnika
	{
		Novi = 1,
		Aktivan = 2,
		Neaktivan = 3,
		Ispisan = 4
	}
}
